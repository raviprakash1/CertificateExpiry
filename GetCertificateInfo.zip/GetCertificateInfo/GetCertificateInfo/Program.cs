﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Net.Mail;
using System.Configuration;

namespace cert_store
{
    class Program
    {
        static void Main(string[] args)
        {            
            string strEmailBody = "";
            string certTabularText = "";
            int intCertCount = 0;
            int numberOfDaysBeforeExpiry = 0;

            if (ConfigurationManager.AppSettings["NumberOfDaysBeforeExpiry"] != null)
                numberOfDaysBeforeExpiry = System.Convert.ToInt32(ConfigurationManager.AppSettings["NumberOfDaysBeforeExpiry"]);
            else
                throw new Exception("Some mandatory configuration values is missing. Please check if corresponding values are given in config file-  NumberOfDaysBeforeExpiry");

            #region Fetch Certificates from Store
            //Fetching certificates from store My - Local. You can also fetch from Trusted People or publisher etc.
            //Store Location can also be changed to LocalMachine or CurrentUser
            //var store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            //var store = new X509Store(StoreName.TrustedPeople, StoreLocation.CurrentUser);
            var store = new X509Store(StoreName.Root, StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadOnly);
            foreach (X509Certificate cert in store.Certificates)
            {
                intCertCount++;
                if (System.DateTime.Today.AddDays(-numberOfDaysBeforeExpiry) < System.Convert.ToDateTime(cert.GetExpirationDateString()))
                {
                    //Fetching Subject, Issuer, Serial Number, Effective Date, Expiration Date and Thumbprint information in tabular form.
                    certTabularText = certTabularText + "<tr><td>" + intCertCount + ")  </td> <td> " + cert.Subject + " </td> <td> " 
                        + cert.Issuer + " </td> <td> " + cert.GetSerialNumberString() + " </td> <td> " + cert.GetEffectiveDateString() 
                        + " </td> <td> " + cert.GetExpirationDateString() + " </td> <td> " + cert.GetCertHashString() + " </td>  </tr>";
                }
            }
            #endregion

            #region Format Email Body
            if (!string.IsNullOrEmpty(certTabularText))
            {
                //Formatting the Email body
                certTabularText = "<table style=\"border: 1px solid black; text-align:center;\" > <tr><td> SNo </td> <td> Subject </td> <td> Issuer </td> <td> Serial Number </td> <td> Effective Date </td> <td> Expiration Date </td> <td> Thumbprint </td>  </tr>" + certTabularText;
                strEmailBody = "There are " + intCertCount.ToString() + " certificates found which are about to expire in " + numberOfDaysBeforeExpiry + " days. \r\n \r\n" + certTabularText + "</tr></table>";
                System.Diagnostics.EventLog.WriteEntry("GetCertificateInfo", "Found " + intCertCount + " Certificates which are about to expire in " + numberOfDaysBeforeExpiry + " days.");
                System.Diagnostics.EventLog.WriteEntry("GetCertificateInfo", "Sending Email");
                sendEmail(strEmailBody);
                System.Diagnostics.EventLog.WriteEntry("GetCertificateInfo", "Email Sent");
            }
            #endregion
        }

        public static void sendEmail(string strEmailBody)
        {
            //Get SMTP details from config
            var appSettings = ConfigurationManager.AppSettings;
            //try
            //{
                MailMessage mail = new MailMessage();
                if ((appSettings["SMTPHost"] != null) && (appSettings["FROMEmailID"] != null) && (appSettings["TOEmailID"] != null) && (appSettings["Subject"] != null) && (appSettings["SMTPServerPort"] != null) && (appSettings["Username"] != null) && (appSettings["Password"] != null))
                {
                    SmtpClient SmtpServer = new SmtpClient(appSettings["SMTPHost"].ToString());
                    mail.From = new MailAddress(appSettings["FROMEmailID"].ToString());
                    mail.To.Add(appSettings["TOEmailID"].ToString());
                    mail.Subject = appSettings["Subject"].ToString();
                    mail.Body = strEmailBody;
                    mail.IsBodyHtml = true;

                    SmtpServer.EnableSsl = true;
                    SmtpServer.DeliveryMethod = SmtpDeliveryMethod.Network;
                    SmtpServer.UseDefaultCredentials = false;
                    SmtpServer.Port = System.Convert.ToInt32(appSettings["SMTPServerPort"]);
                    SmtpServer.Credentials = new System.Net.NetworkCredential(appSettings["Username"].ToString(), 
                        appSettings["Password"].ToString());

                    SmtpServer.Send(mail);
                    Console.WriteLine("Mail Sent");
                }
                else
                {
                    System.Diagnostics.EventLog.WriteEntry("GetCertificateInfo", "Some mandatory configuration values is missing. Please check if corresponding values are given in config file-  SMTPHost, FROMEmailID, ToEmailID, Subject, SMTPServerPort, Username, Password");
                    throw new Exception("Some mandatory configuration values is missing. Please check if corresponding values are given in config file-  SMTPHost, FROMEmailID, ToEmailID, Subject, SMTPServerPort, Username, Password");
                }
            //}
            //catch (Exception expMailSend)
            //{
            //    System.Diagnostics.EventLog.WriteEntry("GetCertificateInfo", expMailSend.InnerException.ToString());
            //    throw new Exception(expMailSend.InnerException.ToString());
            //}
        }
    }
}

